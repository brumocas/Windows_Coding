package com.example.client.communication;

public class communication {
    public static void run() {
        //System.out.println("Starting communications");
    }
}
