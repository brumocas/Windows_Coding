package com.example.client.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class GuiController {

}